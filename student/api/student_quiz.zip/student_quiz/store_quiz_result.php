<?php
include('../db.php');
include('../jwt.php');
header('Content-Type:application/json');

// --- CORS ---
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowed_origins = ['http://localhost:5173', 'http://localhost:3000', 'https://notelibraryapp.com'];
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: https://notelibraryapp.com');
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 1. Validate Token
$authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['status' => 'false', 'message' => 'Unauthorized']);
    exit();
}

$token = $matches[1];
$payload = validateJWT($token);
if (!$payload || !isset($payload['user_id'])) {
    http_response_code(401);
    echo json_encode(['status' => 'false', 'message' => 'Invalid token']);
    exit();
}

$user_id = $payload['user_id'];

// 2. Ensure Tables Exist
$createSummaryTable = "CREATE TABLE IF NOT EXISTS quiz_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    quiz_id INT NOT NULL,
    collection_id INT DEFAULT NULL,
    attempt_number INT DEFAULT 1,
    score FLOAT DEFAULT 0,
    total_questions INT DEFAULT 0,
    correct_count INT DEFAULT 0,
    incorrect_count INT DEFAULT 0,
    attempt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conPrem->query($createSummaryTable);

$createDetailsTable = "CREATE TABLE IF NOT EXISTS quiz_attempt_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attempt_id INT NOT NULL,
    question_index INT NOT NULL,
    selected_option INT DEFAULT -1,
    is_bookmarked TINYINT(1) DEFAULT 0,
    is_correct TINYINT(1) DEFAULT 0,
    INDEX (attempt_id)
)";
$conPrem->query($createDetailsTable);

// 3. Get POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data || !isset($data['quiz_id'])) {
    echo json_encode(['status' => 'false', 'message' => 'Invalid data']);
    exit();
}

$quiz_id = intval($data['quiz_id']);
$collection_id = isset($data['collection_id']) ? intval($data['collection_id']) : null;
$score = floatval($data['score']);
$total_questions = intval($data['total_questions']);
$correct_count = intval($data['correct_count']);
$incorrect_count = intval($data['incorrect_count']);
$responses = isset($data['responses']) ? $data['responses'] : []; // Array of {index, selected, bookmarked, correct}

// Calculate Attempt Number
$attemptQuery = "SELECT COUNT(*) as attempt_count FROM quiz_attempts WHERE user_id = ? AND quiz_id = ?";
$aStmt = $conPrem->prepare($attemptQuery);
$aStmt->bind_param("ii", $user_id, $quiz_id);
$aStmt->execute();
$aStmt->bind_result($attempt_count);
$aStmt->fetch();
$attempt_number = intval($attempt_count) + 1;
$aStmt->close();

// 4. Insert Summary
$insertSummary = "INSERT INTO quiz_attempts (user_id, quiz_id, collection_id, attempt_number, score, total_questions, correct_count, incorrect_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$sStmt = $conPrem->prepare($insertSummary);
$sStmt->bind_param("iiidiiii", $user_id, $quiz_id, $collection_id, $attempt_number, $score, $total_questions, $correct_count, $incorrect_count);

if ($sStmt->execute()) {
    $attempt_id = $sStmt->insert_id;
    $sStmt->close();

    // 5. Insert Details (Snapshots)
    if (!empty($responses)) {
        $insertDetail = "INSERT INTO quiz_attempt_details (attempt_id, question_index, selected_option, is_bookmarked, is_correct) VALUES (?, ?, ?, ?, ?)";
        $dStmt = $conPrem->prepare($insertDetail);
        
        foreach ($responses as $resp) {
            $q_idx = intval($resp['index']);
            $s_opt = intval($resp['selected']);
            $i_bmk = $resp['bookmarked'] ? 1 : 0;
            $i_cor = $resp['correct'] ? 1 : 0;
            
            $dStmt->bind_param("iiiii", $attempt_id, $q_idx, $s_opt, $i_bmk, $i_cor);
            $dStmt->execute();
        }
        $dStmt->close();
    }

    echo json_encode(['status' => 'true', 'message' => 'Result stored successfully', 'attempt' => $attempt_number, 'attempt_id' => $attempt_id]);
} else {
    echo json_encode(['status' => 'false', 'message' => 'Failed to store summary', 'error' => $sStmt->error]);
}
?>
