<?php
include('../db.php');
include('../jwt.php');
include('../encrypt_helper.php');
header('Content-Type:application/json');

// --- CORS Configuration ---
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowed_origins = ['http://localhost:5173', 'http://localhost:3000', 'https://notelibraryapp.com'];
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: https://notelibraryapp.com');
}
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 1. Validate Token
$authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['data' => [], 'status' => 'false', 'message' => 'Unauthorized']);
    exit();
}

$token = $matches[1];
$payload = validateJWT($token);
if (!$payload || !isset($payload['user_id'])) {
    http_response_code(401);
    echo json_encode(['data' => [], 'status' => 'false', 'message' => 'Invalid token']);
    exit();
}

$user_id = $payload['user_id'];
$collection_id = isset($_GET['collection_id']) ? intval($_GET['collection_id']) : 0;

if ($collection_id <= 0) {
    echo json_encode(['status' => 'false', 'message' => 'Invalid collection ID']);
    exit();
}

// 2. Check Access
$accessQuery = "SELECT id FROM user_series_access WHERE user_id = ? AND collection_id = ?";
$stmtAccess = $conPrem->prepare($accessQuery);
$stmtAccess->bind_param("ii", $user_id, $collection_id);
$stmtAccess->execute();
$stmtAccess->store_result();

if ($stmtAccess->num_rows === 0) {
    echo json_encode(['status' => 'false', 'message' => 'Access denied. You have not purchased this collection.']);
    exit();
}
$stmtAccess->close();

// 3. Fetch Quizzes
$query = "SELECT id, quiz_title, competitive_exam, time_limit, negative_marking, mode, start_time, end_time FROM test_series WHERE collection_id = ?";
$stmt = $conPrem->prepare($query);
$stmt->bind_param("i", $collection_id);
$stmt->execute();
$stmt->bind_result($id, $quiz_title, $competitive_exam, $time_limit, $negative_marking, $mode, $start_time, $end_time);

$quizzes = [];
while ($stmt->fetch()) {
    $quizzes[] = [
        'id' => $id,
        'quiz_title' => $quiz_title,
        'competitive_exam' => $competitive_exam,
        'time_limit' => $time_limit,
        'negative_marking' => $negative_marking,
        'mode' => $mode,
        'start_time' => $start_time,
        'end_time' => $end_time
    ];
}

send_encrypted_response(['data' => $quizzes, 'status' => 'true']);
?>
