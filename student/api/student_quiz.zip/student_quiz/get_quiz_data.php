<?php
include('../db.php');
include('../jwt.php');
include('../encrypt_helper.php');
header('Content-Type:application/json');

// --- CORS ---
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$allowed_origins = ['http://localhost:5173', 'http://localhost:3000', 'https://notelibraryapp.com'];
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: https://notelibraryapp.com');
}
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 1. Validate Token
$authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['data' => [], 'status' => 'false', 'message' => 'Unauthorized']);
    exit();
}

$token = $matches[1];
$payload = validateJWT($token);
if (!$payload || !isset($payload['user_id'])) {
    http_response_code(401);
    echo json_encode(['data' => [], 'status' => 'false', 'message' => 'Invalid token']);
    exit();
}

$user_id = $payload['user_id'];
$quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;

if ($quiz_id <= 0) {
    echo json_encode(['status' => 'false', 'message' => 'Invalid quiz ID']);
    exit();
}

// 2. Get Collection ID for this Quiz to check access
$colQuery = "SELECT collection_id FROM test_series WHERE id = ?";
$stmtCol = $conPrem->prepare($colQuery);
$stmtCol->bind_param("i", $quiz_id);
$stmtCol->execute();
$stmtCol->bind_result($collection_id);
if (!$stmtCol->fetch()) {
    echo json_encode(['status' => 'false', 'message' => 'Quiz not found']);
    exit();
}
$stmtCol->close();

// 3. Check User Access to this Collection
$accessQuery = "SELECT id FROM user_series_access WHERE user_id = ? AND collection_id = ?";
$stmtAccess = $conPrem->prepare($accessQuery);
$stmtAccess->bind_param("ii", $user_id, $collection_id);
$stmtAccess->execute();
$stmtAccess->store_result();

if ($stmtAccess->num_rows === 0) {
    echo json_encode(['status' => 'false', 'message' => 'Access denied']);
    exit();
}
$stmtAccess->close();

// 4. Fetch Quiz JSON
$query = "SELECT id, quiz_title, quiz_json, time_limit, negative_marking FROM test_series WHERE id = ?";
$stmt = $conPrem->prepare($query);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id, $quiz_title, $quiz_json, $time_limit, $negative_marking);

if ($stmt->fetch()) {
    send_encrypted_response([
        'status' => 'true',
        'data' => [
            'id' => $id,
            'title' => $quiz_title,
            'questions' => json_decode($quiz_json),
            'time_limit' => $time_limit,
            'negative_marking' => $negative_marking
        ]
    ]);
} else {
    echo json_encode(['status' => 'false', 'message' => 'Failed to fetch quiz data']);
}
?>
