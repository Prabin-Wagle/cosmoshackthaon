<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../db.php';
require_once '../jwt.php';

// Get token from header
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = str_replace('Bearer ', '', $authHeader);

$userData = validateJWT($token);

if (!$userData || $userData['role'] !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Unauthorized access. Admin privileges required."]);
    exit;
}

$ticket_id = $_POST['ticket_id'] ?? '';
$admin_reply = $_POST['admin_reply'] ?? '';
$status = $_POST['status'] ?? 'answered'; // Default to answered if not provided

if (empty($ticket_id) || empty($admin_reply)) {
    echo json_encode(["status" => "error", "message" => "Ticket ID and admin reply are required"]);
    exit;
}

// Validate status
$allowed_statuses = ['pending', 'answered', 'closed'];
if (!in_array($status, $allowed_statuses)) {
    $status = 'answered';
}

$stmt = $conSupport->prepare("UPDATE tickets SET admin_reply = ?, status = ? WHERE id = ?");
$stmt->bind_param("ssi", $admin_reply, $status, $ticket_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["status" => "success", "message" => "Admin reply added and status updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Ticket not found or no changes made"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update ticket: " . $stmt->error]);
}

$stmt->close();
$conSupport->close();
?>
